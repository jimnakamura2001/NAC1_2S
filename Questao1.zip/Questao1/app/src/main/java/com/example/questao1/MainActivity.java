package com.example.questao1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void consultar(View view){

        EditText consulta = findViewById(R.id.localParaEscrever);
        TextView titulo = findViewById(R.id.localparaReceberTitle);
        TextView complete = findViewById(R.id.localParaReceberCompleted);
        TextView status = findViewById(R.id.status);

        String url = "https://jsonplaceholder.typicode.com/todos/";

        url += consulta.getText().toString();

        new DataGetter(titulo, complete, status).execute(url);
    }
}
