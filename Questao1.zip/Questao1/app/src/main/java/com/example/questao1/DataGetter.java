package com.example.questao1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class DataGetter extends AsyncTask<String, Void, String> {

    private TextView txtNome;
    private TextView txtSobrenome;
    private TextView txtMensagem;

    public DataGetter(TextView txtNome, TextView txtSobrenome, TextView txtMensagem) {
        this.txtNome = txtNome;
        this.txtSobrenome = txtSobrenome;
        this.txtMensagem = txtMensagem;

        txtMensagem.setText("FazendoBusca...");
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        String result = NetworkToolKit.doGet(url);


        return result;
    }

    @Override
    protected void onPostExecute(String s) {

        txtMensagem.setText("Deu bom!");


        try{
            JSONObject jsonResponse = new JSONObject(s);

            int id = jsonResponse.getInt("id");

            String firstName = jsonResponse.getString("title");
            String lastName = jsonResponse.getString("completed");

            txtNome.setText(firstName);
            txtSobrenome.setText(lastName);

        }
        catch(JSONException e){
            this.txtNome.setText("Insira o ID acima");
            this.txtSobrenome.setText("Insira o ID acima");
        }
    }
}
