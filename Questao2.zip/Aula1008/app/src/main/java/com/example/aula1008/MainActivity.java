package com.example.aula1008;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class MainActivity extends AppCompatActivity {

    private String file_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //PARA SALVAR É PRECISO FAZER O SEGUINTE:
        //Obtendo o caminhao de gravação
        this.file_name = getApplicationContext().getFilesDir().getPath() + "/";


        final EditText texto = findViewById(R.id.contextBox);
        final EditText fileNameToOpen = findViewById(R.id.fileName);
        final Button btApagar = findViewById(R.id.apagar);
        final Button btRecuperar = findViewById(R.id.recuperar);
        final Button btSalve = findViewById(R.id.salvar);

        Toast.makeText(MainActivity.this, "BEM VINDO A QUESTAO 2", Toast.LENGTH_SHORT).show();

        btApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto.setText("");
            }
        });

        btRecuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fileNameToOpen.getText().length() == 0){
                    Toast.makeText(MainActivity.this, "Tem que colocar o nome", Toast.LENGTH_SHORT).show();
                }
                else{
                    String completeFN = file_name + fileNameToOpen.getText().toString();
                    String content = recuperaDados(completeFN);
                    texto.setText(content);
                }
            }
        });

        btSalve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fileNameToOpen.getText().length() == 0){
                    Toast.makeText(MainActivity.this, "Tem que colocar o nome", Toast.LENGTH_SHORT).show();
                }
                else{
                    String completeFN = file_name + fileNameToOpen.getText().toString();
                    String content = texto.getText().toString();
                    MainActivity.this.gravaDados(completeFN, content);
                }
            }
        });

    }

    public void gravaDados(String file_name, String data){

        try {
            OutputStreamWriter buuferSaida = new OutputStreamWriter(new FileOutputStream(file_name), "UTF-8");
            buuferSaida.write(data);
            buuferSaida.close();
            Toast.makeText(MainActivity.this, "Dados Salvos", Toast.LENGTH_SHORT).show();
        }
        catch(FileNotFoundException e){
            Toast.makeText(this, "Arquivo não encontrado", Toast.LENGTH_SHORT).show();
        }
        catch(UnsupportedEncodingException e){
            Toast.makeText(this, "DEU RUIM 2 ", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e){
            Toast.makeText(this, "DEU RUIM 3", Toast.LENGTH_SHORT).show();
        }
    }

    public String recuperaDados(String file_name){

        try {
            //PERMITE LER
            BufferedReader bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(file_name), "UTF-8"));

            StringBuilder sb = new StringBuilder();
            String linha = bufferReader.readLine();

            while(linha != null){

                sb.append(linha);
                sb.append("\n");
                linha = bufferReader.readLine();
            }
            return sb.toString();
        }
        catch(FileNotFoundException e){
            Toast.makeText(this, "Arquivo não encontrado", Toast.LENGTH_SHORT).show();
        }
        catch(UnsupportedEncodingException e){
            Toast.makeText(this, "DEU RUIM 2", Toast.LENGTH_SHORT).show();
        }
        catch(IOException e){
            Toast.makeText(this, "DEU RUIM 3", Toast.LENGTH_SHORT).show();
        }
        return "";
    }
}
